#include <iostream>
#include <cmath>

using namespace std;

// addition function
double add(double a, double b) {
    return a + b;
}

// substraction function
double subtract(double a, double b) {
    return a - b;
}

// mutliplication function
double multiply(double a, double b) {
    return a * b;
}

//division function 
double divide(double a, double b) {
    if (b != 0)
        return a / b;
    else {
        cout << "Error: cannot divide by 0." << endl;
        return NAN;
    }
}

// modulus function 
double Moduluss(double a, double b) {
    return fmod(a, b);
}

//exponent function
double exponent(double base, double exponent) {
    return pow(base, exponent);
}

// sin function
double sin(double angle) {
    return sin(angle);
}

// arcsin function
double arcsin(double value) {
    return asin(value);
}

// cosin function
double cosin(double angle) {
    return cos(angle);
}

// arccosin function
double arccosin(double value) {
    return acos(value);
}

// tan function
double tangent(double angle) {
    return tan(angle);
}

// atan function
double arctangent(double value) {
    return atan(value);
}

// atan2 function
double arctangent2(double y, double x) {
    return atan2(y, x);
}

// sqrt function
double squareRoot(double value) {
    if (value >= 0)
        return sqrt(value);
    else {
        cout << "Error: Square root of a negative number" << endl;
        return NAN; // 
    }
}

// ceiling function 
double ceilValue(double value) {
    return ceil(value);
}

// absolute function
double absolute(double value) {
    return abs(value);
}

// floor function
double floorValue(double value) {
    return floor(value);
}

// max function
double maximum(double a, double b) {
    return max(a, b);
}

// min function
double minimum(double a, double b) {
    return min(a, b);
}

// log function
double logarithm(double value) {
    if (value > 0)
        return log(value);
    else {
        cout << "Error: Logarithm of a non positive number" << endl;
        return NAN; 
    }
}

// log10 function
double logarithm10(double value) {
    if (value > 0)
        return log10(value);
    else {
        cout << "Error: Logarithm of a non positive number" << endl;
        return NAN; 
    }
}

//log2 function 
double logarithm2(double value) {
    if (value > 0)
        return log2(value);
    else {
        cout << "Error: Logarithm of a non positive number" << endl;
        return NAN; 
    }
}

// round function
double roundValue(double value) {
    return round(value);
}

int main() {
    // declare variables
    char operand;
    double nb1, nb2;

    cout << "Enter the operator (+, -, *, /, %, ^, sin (S), asin (A), cos (C), acos (D), tan (T), atan (N), atan2 (R), sqrt (Q), ceil (V), abs (B), floor (F), max (X), min (M), log (L), log10 (G), log2 (H), round (Y)): ";
    cin >> operand;

    if (operand == '+' || operand == '-' || operand == '*' || operand == '/' || operand == '%' || operand == '^') {
        cout << "Enter 2 numbers: ";
        cin >> nb1 >> nb2;
    }
    else if (toupper(operand) == 'S' || toupper(operand) == 'C' || toupper(operand) == 'T' || toupper(operand) == 'A'|| toupper(operand) == 'N'|| toupper(operand) == 'D') {
        cout << "Enter an angle in radians: ";
        cin >> nb1;
    }
    else if (toupper(operand) == 'R') {
        cout << "Enter 2 angles x and y in radians: ";
        cin >> nb1 >> nb2;
    }
    else if (toupper(operand) == 'Q' || toupper(operand) == 'V' || toupper(operand) == 'B' || toupper(operand) == 'Y'|| toupper(operand) == 'F') {
        cout << "Enter a number: ";
        cin >> nb1;
    }
    else if (toupper(operand) == 'X' || toupper(operand) == 'M' ) {
        cout << "Enter 2 numbers: ";
        cin >> nb1 >> nb2;
    }
    else if (toupper(operand) == 'L' || toupper(operand) == 'G' || toupper(operand) == 'H' ) {
        cout << "Enter a positive number: ";
        cin >> nb1;
    }
    else {
        cout << "Invalid operator!" << endl;
        return 0;
    }

    // Based on the operand chosen by the user, an operation is performed
    switch (operand) {
        case '+':
            cout << "Result: " << add(nb1, nb2) << endl;
            break;
        case '-':
            cout << "Result: " << subtract(nb1, nb2) << endl;
            break;
        case '*':
            cout << "Result: " << multiply(nb1, nb2) << endl;
            break;
        case '/':
            cout << "Result: " << divide(nb1, nb2) << endl;
            break;
        case '%':
            cout << "Result: " << Moduluss(nb1, nb2) << endl;
            break;
        case '^':
            cout << "Result: " << exponent(nb1, nb2) << endl;
            break;
        case 's':
        case 'S':
            cout << "Result: " << sine(nb1) << endl;
            break;
        case 'a':
        case 'A':
            cout << "Result: " << arcsine(nb1) << endl;
            break;
        case 'c':
        case 'C':
            cout << "Result: " << cosine(nb1) << endl;
            break;
        case 'd':
        case 'D':
            cout << "Result: " << arccosine(nb1) << endl;
            break;
        case 't':
        case 'T':
            cout << "Result: " << tangent(nb1) << endl;
            break;
        case 'n':
        case 'N':
            cout << "Result: " << arctangent(nb1) << endl;
            break;
        case 'r':
        case 'R':
            cout << "Result: " << arctangent2(nb1, nb2) << endl;
            break;
        case 'q':
        case 'Q':
            cout << "Result: " << squareRoot(nb1) << endl;
            break;
        case 'v':
        case 'V':
            cout << "Result: " << ceilValue(nb1) << endl;
            break;
        case 'b':
        case 'B':
            cout << "Result: " << absolute(nb1) << endl;
            break;
        case 'f':
        case 'F':
            cout << "Result: " << floorValue(nb1) << endl;
            break;
        case 'x':
        case 'X':
            cout << "Result: " << maximum(nb1, nb2) << endl;
            break;
        case 'm':
        case 'M':
            cout << "Result: " << minimum(nb1, nb2) << endl;
            break;
        case 'l':
        case 'L':
            cout << "Result: " << logarithm(nb1) << endl;
            break;
        case 'g':
        case 'G':
            cout << "Result: " << logarithm10(nb1) << endl;
            break;
        case 'h':
        case 'H':
            cout << "Result: " << logarithm2(nb1) << endl;
            break;
        case 'y':
        case 'Y':
            cout << "Result: " << roundValue(nb1) << endl;
            break;
        default:
            cout << "Invalid operator!" << endl;
            break;
    }

    return 0;
}
