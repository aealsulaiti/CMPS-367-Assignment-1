#include <iostream>

using namespace std;

// Function to generate te multiplication table using the starting and ending range for multiplication table and for multiplying nbs in the multiplication table
void multiplicationTable(int startingRange, int endingRange, int startingMultiplyNb, int endingMultiplyNb) {
    cout <<endl;
    cout<<"Here is the multiplication table for " << startingRange << " to " << endingRange << " in the range of " << startingMultiplyNb << " to " << endingMultiplyNb << endl;
    cout << "X\t";
    for (int i = startingMultiplyNb; i <= endingMultiplyNb; ++i) {
        cout << i << "\t";
    }
    cout << endl;
    for (int i = startingRange; i <= endingRange; ++i) {
        cout << i << "\t";
        for (int j = startingMultiplyNb; j <= endingMultiplyNb; ++j) {
            cout << i * j << "\t";
        }
        cout << endl;
    }
}

int main() {
    // declare variable choice to ask the user after generating his first multiplying table if he wanna continue or not
    char choice;
    // do while to repeat the process and ask the user each time if he wanna continue or not
    do {
        int startingRange, endingRange, startingMultiplyNb, endingMultiplyNb;
        
        cout << "Enter the starting range for Multiplication Table: ";
        cin >> startingRange;
        
        cout << "Enter the ending range for Multiplication Table: ";
        cin >> endingRange;
        
        cout << "Enter the starting range for multiplying the numbers in Multiplication Table: ";
        cin >> startingMultiplyNb;
        
        cout << "Enter the ending range for multiplying the numbers in Multiplication Table: ";
        cin >> endingMultiplyNb;
        
        multiplicationTable(startingRange, endingRange, startingMultiplyNb, endingMultiplyNb);
        cout<<endl;
        
        cout << "Do you want to create another multiplication table? (Y/N): ";
        cin >> choice;
        
    } while(choice == 'y' || choice == 'Y');
    
    cout << "Thank you for using the multiplication table generator." << endl;
    
    return 0;
}
