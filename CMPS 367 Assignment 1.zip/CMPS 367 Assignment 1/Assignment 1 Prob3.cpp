#include <iostream>
#include <string>
#include <cmath>

using namespace std;

int main() {
    // declare variables
    string name, gender, category;
    int age,feet;
    float inches, weight, bmi;
    
    cout << "Please enter your name: ";
    getline(cin, name);
    
    cout << "Please enter your age: ";
    cin >> age;
    
    cout << "Please enter your gender (male/female): ";
    cin >> gender;
    
    cout << "Please enter your height in feet: ";
    cin >> feet;
    
    cout << "Please enter your height in inches: ";
    cin >> inches;
    
    cout << "Please enter your weight in pounds: ";
    cin >> weight;
    
    // Convert height to inches
    float height_inches = (feet * 12) + inches;
    
    // Calculate BMI using provided formula
    bmi = (703.0 * weight) / (height_inches * height_inches);
    
    // if else statements to determine the BMI category
    if (bmi < 16)
        category = "Severe Thinness";
    else if (bmi >= 16 && bmi < 17)
        category = "Moderate Thinness";
    else if (bmi >= 17 && bmi < 18.5)
        category = "Mild Thinness";
    else if (bmi >= 18.5 && bmi < 25)
        category = "Normal";
    else if (bmi >= 25 && bmi < 30)
        category = "Overweight";
    else if (bmi >= 30 && bmi < 35)
        category = "Obese class I";
    else if (bmi >= 35 && bmi < 40)
        category = "Obese class II";
    else
        category = "Obese class III";
    
    cout << endl;
    cout << "Hi " << name << "," << endl;
    cout << "You are a " << gender << ". You are " << age << " years old." << endl;
    cout << "You are currently " << feet << "'" << inches << "\" and you currently weight " << weight << " pounds." << endl;
    cout << "Your BMI is " << bmi << ", which is " << category << "." << endl;
    cout << "Thank you for using the BMI Calculator!" << endl;
    
    return 0;
}
