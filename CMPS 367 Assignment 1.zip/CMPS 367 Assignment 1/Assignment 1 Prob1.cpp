#include <iostream>
#include <string>
#include <stack>
#include <cmath>

using namespace std;

// function to check if the character is an operator or not
bool isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

// function to define precedence order
int Precedence(char op) {
    if (op == '^')
        return 3;
    else if (op == '*' || op == '/')
        return 2;
    else if (op == '+' || op == '-')
        return 1;
    else
        return 0; 
}

// function to apply the operation
double applyOperation(double a, double b, char op) {
    switch (op) {
        case '+':
            return a + b;
        case '-':
            return a - b;
        case '*':
            return a * b;
        case '/':
            return a / b;
        case '^':
            return pow(a, b);
        default:
            cout<< "Error: Invalid operator" << endl;
            return 0;
    }
}

// function to solve the operation/expression
float solveExpression(string expression) {
    stack<double> operands;
    stack<char> operators;
    double operand = 0;
    bool neg = false;

    cout << "Here are the steps:" << endl;
    cout << expression << endl;

    for (char c : expression) {
        if (isdigit(c) || c == '.') {
            operand = operand * 10 + (c - '0');
        } else if (c == '-') {
            if (operand == 0 && !neg) {
                neg = true;
            } else {
                operands.push(neg ? -operand : operand);
                operand = 0;
                neg = false;
                while (!operators.empty() && (operators.top() == '*' || operators.top() == '/' || operators.top() == '^')) {
                    double b = operands.top(); operands.pop();
                    double a = operands.top(); operands.pop();
                    char op = operators.top(); operators.pop();
                    double res = applyOperation(a, b, op);
                    operands.push(res);
                    cout << a << " " << op << " " << b << " = " << res << endl;
                }
                operators.push('-');
            }
        } else if (isOperator(c)) {
            operands.push(neg ? -operand : operand);
            operand = 0;
            neg = false;
            while (!operators.empty() && Precedence(operators.top()) >= Precedence(c)) {
                double b = operands.top(); operands.pop();
                double a = operands.top(); operands.pop();
                char op = operators.top(); operators.pop();
                double res = applyOperation(a, b, op);
                operands.push(res);
                cout << a << " " << op << " " << b << " = " << res << endl;
            }
            operators.push(c);
        } else if (c == '(') {
            int count = 1;
            string subExpression;
            auto i = expression.begin() + 1;
            while (count > 0) {
                subExpression.push_back(*i);
                if (*i == '(') {
                    ++count;
                } else if (*i == ')') {
                    --count;
                }
                ++i;
            }
            double subRes = solveExpression(subExpression);
            operands.push(subRes);
            cout << "(" << subRes << ")";
            operand = 0;
            neg = false;
            c = *i; 
        }
    }
    operands.push(neg ? -operand : operand);

    while (!operators.empty()) {
        double b = operands.top(); operands.pop();
        double a = operands.top(); operands.pop();
        char op = operators.top(); operators.pop();
        double res = applyOperation(a, b, op);
        operands.push(res);
        cout << a << " " << op << " " << b << " = " << res << endl;
    }

    double finalRes = operands.top();
    cout << "The answer to this problem is " << finalRes << "." << endl;
    return finalRes;
}

int main() {
    // declare variable choice to ask the user in the end if he want to re-enter another operation or not
    char choice;
    do {
        string expression;
        cout << "Enter a problem to solve: ";
        getline(cin, expression);
        solveExpression(expression);

        cout << "Would you like to solve another problem? (Y/N) ";
        cin >> choice;
        cin.ignore(); // Clear the input buffer
    } while (choice == 'Y' || choice == 'y');

    cout << "Thank you for using this calculator!" << endl;

    return 0;
}
