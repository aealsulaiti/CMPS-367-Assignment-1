#include <iostream>
#include <string>

using namespace std;

// Function to display the meaning of the month
void displayMonthMeaning(string month) {
    if(month == "January") {
        cout << "The month of January means Janus" << endl;
    }
    else if(month == "February") {
        cout << "The month of February means Februalia "<< endl;;
    }
    else if(month == "March") {
        cout << "The month of March means Mars " << endl;;
    }
    else if(month == "April") {
        cout << "The month of April means open buds " << endl;;
    }
    else if(month == "May") {
        cout << "The month of May means Maia " << endl;;
    }
    else if(month == "June") {
        cout << "The month of June means Youth " << endl;;
    }
    else if(month == "July") {
        cout << "The month of July means Julius Caesar " << endl;;
    }
    else if(month == "August") {
        cout << "The month of August means Augustus Caesar " << endl;;
    }
    else if(month == "September") {
        cout << "The month of September means Seven " << endl;;
    }
    else if(month == "October") {
        cout << "The month of October means Eight " << endl;;
    }
    else if(month == "November") {
        cout << "The month of November means Nine " << endl;;
    }
    else if(month == "December") {
        cout << "The month of December means Ten " << endl;;
    }
       
    else {
        cout << "Invalid month" << endl;
    }
}

// Function to display the meaning of the day
void displayDayMeaning(int day,string month) {
    switch(day) {
        case 1:
            cout << "The 1st of " << month << " means Self-Started" << endl;
            break;
             case 2:
            cout << "The 2nd of " << month << " means Great Talent" << endl;
            break;
             case 3:
            cout << "The 3rd of " << month << " means Very Skilled" << endl;
            break;
             case 4:
            cout << "The 4th of " << month << " means You Are the Rock" << endl;
            break;
             case 5:
            cout << "The 5th of " << month << " means Flexibility" << endl;
            break;
             case 6:
            cout << "The 6th of " << month << " means Natural Born Nurturer" << endl;
            break;
             case 7:
            cout << "The 7th of " << month << " means Refined Mind" << endl;
            break;
             case 8:
            cout << "The 8th of " << month << " means Self-Sufficient" << endl;
            break;
             case 9:
            cout << "The 9th of " << month << " means Your Soul is Most Satisfied" << endl;
            break;
             case 10:
            cout << "The 10th of " << month << " means LeaderShip Skills" << endl;
            break;
            case 11:
            cout << "The 11th of " << month << " means Keen Awarness" << endl;
            break;
            case 12:
            cout << "The 12th of " << month << " means Creativity and Imagination" << endl;
            break;
            case 13:
            cout << "The 13th of " << month << " means Conscientious Worker" << endl;
            break; 
            case 14:
            cout << "The 14th of " << month << " means Open-Minded" << endl;
            break; 
            case 15:
            cout << "The 15th of " << month << " means Powerful-Love" << endl;
            break; 
            case 16:
            cout << "The 16th of " << month << " means Inquisitive Mind" << endl;
            break; 
            case 17:
            cout << "The 17th of " << month << " means Quality of Work" << endl;
            break;
             case 18:
            cout << "The 18th of " << month << " means Open-Minded and Open-Hearted " << endl;
            break;
             case 19:
            cout << "The 19th of " << month << " means Independence" << endl;
            break;
             case 20:
            cout << "The 20th of " << month << " means Cooperative RelationShips" << endl;
            break;
             case 21:
            cout << "The 21st of " << month << " means Connect with People" << endl;
            break;
             case 22:
            cout << "The 22nd of " << month << " means Determined and Hard Working" << endl;
            break;
             case 23:
            cout << "The 23rd of " << month << " means Real Zest for Life" << endl;
            break;
             case 24:
            cout << "The 24th of " << month << " means Heart of Gold " << endl;
            break;
             case 25:
            cout << "The 25th of " << month << " means Process Information " << endl;
            break;
             case 26:
            cout << "The 26th of " << month << " means Desire to Succeed" << endl;
            break;
             case 27:
            cout << "The 27th of " << month << " means Tolerant " << endl;
            break;
             case 28:
            cout << "The 28th of " << month << " means Capable Leader " << endl;
            break;
             case 29:
            cout << "The 29th of " << month << " means Ability to Bring Things Together " << endl;
            break;
             case 30:
            cout << "The 30th of " << month << " means Innovative Thinker " << endl;
            break;
             case 31:
            cout << "The 31st of " << month << " means Stirring Mind " << endl;
            break;
        default:
            cout << "Invalid day" << endl;
            break;
    }
}

// Function to display the meaning of the year
void displayYearMeaning(int year) {
    switch(year) {
        case 2000:
            cout << "The year 2000 means that you are a millennial" << endl;
            break;
            case 2001:
            cout << "The year 2001 means that you are very passionate" << endl;
            break;
            case 2002:
            cout << "The year 2002 means that you need discipline" << endl;
            break;
            case 2003:
            cout << "The year 2003 means that you have a tendency to worry" << endl;
            break;
            case 2004:
            cout << "The year 2004 means that you are a strong-willed" << endl;
            break;
            case 2005:
            cout << "The year 2005 means that you are honest, intelligent, and ambitious" << endl;
            break;
            case 2006:
            cout << "The year 2006 means that you are straightforward" << endl;
            break;
            case 2007:
            cout << "The year 2007 means that people find you honest" << endl;
            break;
            case 2008:
            cout << "The year 2008 means that you are easy going, adaptable, and fit" << endl;
            break;
            case 2009:
            cout << "The year 2009 means that you are silent, and hardworking" << endl;
            break;
            case 2010:
            cout << "The year 2010 means that you have a tendency to resist" << endl;
            break;
            case 2011:
            cout << "The year 2011 means that you are sensitive" << endl;
            break;
            case 2012:
            cout << "The year 2012 means that you are impatient" << endl;
            break;
            case 2013:
            cout << "The year 2013 means that you have a lot of energy" << endl;
            break;
            case 2014:
            cout << "The year 2014 means that you desire a high-profile career" << endl;
            break;
            case 2015:
            cout << "The year 2015 means that you have strong faith" << endl;
            break;
            case 2016:
            cout << "The year 2016 means that you have spent your life caring for others" << endl;
            break;
            case 2017:
            cout << "The year 2017 means that people find you faithful and smart" << endl;
            break;
        default:
            cout << "Invalid year" << endl;
            break;
    }
}

int main() {
    //declare variable 
    char choice;
    
    cout << "Welcome to Birthday Date Meaning Generator!" << endl;
    
    do {
        int day, year;
        string month;
        
        cout << "Please enter the month of your birthday: ";
        cin >> month;
        
        cout << "Please enter the day of your birthday: ";
        cin >> day;
        
        cout << "Please enter the year of your birthday: ";
        cin >> year;
        
        // Calling the procedures
        displayMonthMeaning(month);
        displayDayMeaning(day, month); 
        displayYearMeaning(year);
        
        cout << "Would you like to try another one? (Y/N): ";
        cin >> choice;
        
    } while(choice == 'Y' || choice == 'y');
    
    cout << "Thanks for playing!" << endl;
    
    return 0;
}
